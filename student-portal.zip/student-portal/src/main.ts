import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppRoutingModule } from './app/app.module';

bootstrapApplication(AppRoutingModule, appConfig)
  .catch((err) => console.error(err));
