import { Injectable, signal } from "@angular/core";

@Injectable({
    providedIn :'root',
})

export class AuthService{
    private isLoggedInSignal = signal<boolean>(this.getLoginStatus());


    private getLoginStatus():boolean {
        return localStorage.getItem('isLoggedIn') === 'true';
    }

    isLoggedIn(){
        return this.isLoggedInSignal();
    }

    login(username:string , password :string) : boolean {
        if(username === 'admin' && password === 'admin'){
            this.isLoggedInSignal.set(true);
            return true;
        }else{
            return false;
        }
    }

    logout():void {
        localStorage.removeItem('isloggedIn');
        this.isLoggedInSignal.set(false);
    }
}