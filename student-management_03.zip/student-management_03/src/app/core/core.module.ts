import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { StudentModule } from '../student/student.module';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';

@NgModule({
  declarations: [HeaderComponent, FooterComponent],
  imports: [CommonModule, StudentModule],
  exports: [HeaderComponent, FooterComponent], // Export them for AppModule
})
export class CoreModule {}
