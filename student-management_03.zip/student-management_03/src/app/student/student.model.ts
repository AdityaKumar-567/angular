export interface Student {
  id: string;
  name: string;
  age: number;
  address: string;
  branch: string;
  cgpa: number;
  projects: string[];
  hobbies: string[];
}
