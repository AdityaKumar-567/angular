import { Component, signal } from '@angular/core';
import { Student } from '../student.model';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css'],
})
export class StudentListComponent {
  students = signal<Student[]>([]);
  selectedStudent = signal<Student | null>(null);

  constructor(private studentService: StudentService) {
    this.loadStudents();
  }

  loadStudents() {
    this.students.set(this.studentService.getStudents());
  }

  selectStudent(student: Student): void {
    this.selectedStudent.set(student);
  }
  onStudentRemoved() {
    this.loadStudents(); // Refresh student list
    if (this.selectedStudent() && !this.students().some(s => s.id === this.selectedStudent()!.id)) {
      this.selectedStudent.set(null); // Clear selected student if removed
    }
  }
  

}
