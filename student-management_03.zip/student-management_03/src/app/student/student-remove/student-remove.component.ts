import { Component, Output, EventEmitter, signal, output } from '@angular/core';
import { Student } from '../student.model';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-remove',
  templateUrl: './student-remove.component.html',
  styleUrls: ['./student-remove.component.css']
})
export class StudentRemoveComponent {

  searchQuery = '';
  students = signal<Student[]>([]);
  selectedStudent: Student | null = null;

  // @Output() close = new EventEmitter<void>(); // Close modal event
  // @Output() studentRemoved = new EventEmitter<void>(); // Notify parent component

  close = output();
  studentRemoved = output();

  constructor(private studentService: StudentService) {
    this.loadStudents();
  }

  loadStudents() {
    this.students.set(this.studentService.getStudents());
  }

  onSearchChange(query: string) {
    this.searchQuery = query;
    const filtered = this.studentService.getStudents().filter(student => 
      student.name.toLowerCase().includes(query.toLowerCase())
    );
    this.students.set(filtered);
  }

  selectStudent(student: Student) {
    this.selectedStudent = student;
  }

  removeStudent() {
    if (this.selectedStudent) {
      this.studentService.removeStudent(this.selectedStudent.id);
      this.studentRemoved.emit();  // Emit event when student is removed
      this.close.emit();
    }
  }

  closeModal() {
    this.close.emit();
  }
}
