import { StudentRemoveComponent } from './student-remove/student-remove.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { StudentAddComponent } from './student-add/student-add.component';
import { StudentDetailsComponent } from './student-details/student-details.component';
import { StudentListComponent } from './student-list/student-list.component';

@NgModule({
  declarations: [
    StudentListComponent,
    StudentDetailsComponent,
    StudentAddComponent,
    StudentRemoveComponent
  ],
  imports: [CommonModule, FormsModule],
  exports: [StudentListComponent, StudentDetailsComponent, StudentAddComponent, StudentRemoveComponent],
})
export class StudentModule {}
