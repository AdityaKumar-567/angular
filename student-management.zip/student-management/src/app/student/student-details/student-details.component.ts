import { Component } from '@angular/core';
import { FormsModule  } from '@angular/forms';


import { Student } from './student.model';

import { StudentService } from './student.service';

@Component({
  selector: 'app-student-details',
  standalone: true,
  templateUrl: './student-details.component.html',
  styleUrls: ['./student-details.component.css'],
  imports: [FormsModule],
})
export class StudentDetailsComponent{
  students: Student[] = [];
  selectedStudent?: Student;

  constructor(private studentService: StudentService) {
    this.students = this.studentService.getStudents();
  }

  selectStudent(student: Student): void {
    this.selectedStudent = student;
  }
}