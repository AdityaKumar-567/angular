import { Component, signal } from '@angular/core';
import { Student } from '../student/student.model';
import { StudentService } from '../student/student.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrl: './user.component.css',
})
export class UserComponent {
  students = signal<Student[]>([]); // ✅ Stores all students

  constructor(private studentService: StudentService) {
    this.loadStudents();
  }

  loadStudents() {
    this.students.set(this.studentService.getStudents()); // ✅ Fetch students from service
  }
}
