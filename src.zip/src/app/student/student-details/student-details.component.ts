import {
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  Output,
  signal,
} from '@angular/core';
import { Student } from '../student.model';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-details',
  templateUrl: './student-details.component.html',
  styleUrls: ['./student-details.component.css'],
})
export class StudentDetailsComponent implements OnDestroy {
  @Input() selectedStudent!: Student | null;
  @Output() studentRemoved = new EventEmitter<string>();

  isUpdateModalOpen = signal(false);
  studentToUpdate = signal<Student | null>(null);

  // ✅ Confirmation popup controls
  isConfirmPopUpOpen = signal(false);
  confirmMessage = signal<string>(''); // ✅ Ensure confirmMessage is a string signal
  confirmAction: (() => void) | null = null;

  constructor(private studentService: StudentService) {}

  confirmRemoveStudent(): void {
    if (this.selectedStudent) {
      this.confirmMessage.set(
        `Are you sure you want to remove ${this.selectedStudent.name}?`
      );
      this.confirmAction = () => this.removeStudent();
      this.isConfirmPopUpOpen.set(true);
    }
  }

  confirmSaveStudent(updatedStudent: Student): void {
    this.confirmMessage.set(`Confirm changes to ${updatedStudent.name}?`);
    this.confirmAction = () => this.updateStudent(updatedStudent);
    this.isConfirmPopUpOpen.set(true);
  }

  executeConfirmAction(): void {
    if (this.confirmAction) {
      this.confirmAction();
    }
    this.isConfirmPopUpOpen.set(false);
  }

  closeConfirmPopUp(): void {
    this.isConfirmPopUpOpen.set(false);
  }

  removeStudent(): void {
    if (this.selectedStudent) {
      console.log(`Removing student: ${this.selectedStudent.name}`);
      this.studentRemoved.emit(this.selectedStudent.id);
    }
  }

  openUpdateModal(): void {
    if (this.selectedStudent) {
      this.studentToUpdate.set({ ...this.selectedStudent });
      this.isUpdateModalOpen.set(true);
    }
  }

  closeUpdateModal(): void {
    this.isUpdateModalOpen.set(false);
  }

  updateStudent(updatedStudent: Student): void {
    this.studentService.updateStudent(updatedStudent);
    this.selectedStudent = updatedStudent;
    this.isUpdateModalOpen.set(false);
  }

  ngOnDestroy(): void {
    console.log('StudentDetailsComponent is being destroyed.');
  }
}
