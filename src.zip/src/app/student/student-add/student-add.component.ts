import { Component, output, signal } from '@angular/core';
import { v4 as uuidv4 } from 'uuid';
import { Student } from '../student.model';

@Component({
  selector: 'app-student-add',
  templateUrl: './student-add.component.html',
  styleUrls: ['./student-add.component.css'],
})
export class StudentAddComponent {
  // @Output() close = new EventEmitter<void>(); // Emit for closing modal
  // @Output() studentAdded = new EventEmitter<Student>(); // Emit new student
  close = output();
  studentAdded = output<Student>();

  //  Use standard object instead of signal() for ngModel compatibility
  newStudent: Partial<Student> = {
    name: '',
    age: 0,
    address: '',
    branch: '',
    cgpa: 0,
    result: '',
    projects: [],
    hobbies: [],
  };

  private _projectsInput = signal('');
  private _hobbiesInput = signal('');

  //  Getter and Setter for projectsInput
  get projectsInput() {
    return this._projectsInput();
  }
  set projectsInput(value: string) {
    this._projectsInput.set(value);
  }

  //  Getter and Setter for hobbiesInput
  get hobbiesInput() {
    return this._hobbiesInput();
  }
  set hobbiesInput(value: string) {
    this._hobbiesInput.set(value);
  }

  addStudent(): void {
    if (!this.newStudent.name) return; // Ensure name is not empty

    const student: Student = {
      id: uuidv4(),
      name: this.newStudent.name!,
      age: this.newStudent.age!,
      address: this.newStudent.address!,
      branch: this.newStudent.branch!,
      cgpa: this.newStudent.cgpa!,
      result: this.newStudent.result!,
      projects: this.projectsInput.split(',').map((p) => p.trim()),
      hobbies: this.hobbiesInput.split(',').map((h) => h.trim()),
    };

    this.studentAdded.emit(student);

    this.closeModal();
  }

  closeModal(): void {
    this.close.emit();
  }
}
