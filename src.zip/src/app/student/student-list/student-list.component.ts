import { Component, computed, OnInit, signal } from '@angular/core';
import { Student } from '../student.model';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css'],
})
export class StudentListComponent implements OnInit {
  students = signal<Student[]>([]);
  selectedStudent = signal<Student | null>(null);

  // Compute the total number of students dynamically
  studentCount = computed(() => this.students().length);

  //Compute if a student is selected
  isStudentSelected = computed(() => this.selectedStudent() !== null);

  constructor(private studentService: StudentService) {}
  ngOnInit(): void {
    this.loadStudents();
  }
  loadStudents() {
    this.students.set(this.studentService.getStudents());
  }

  selectStudent(student: Student): void {
    this.selectedStudent.set(student);
  }

  removeStudent(studentId: string): void {
    this.studentService.removeStudent(studentId);
    this.students.set(this.studentService.getStudents());
    this.selectedStudent.set(null);
  }
}
