import { Component, input, output } from '@angular/core';

@Component({
  selector: 'app-confirm-pop-up',
  templateUrl: './confirm-pop-up.component.html',
  styleUrls: ['./confirm-pop-up.component.css'],
})
export class ConfirmPopUpComponent {
  message = input<string>();
  confirm = output<void>();
  cancel = output<void>();
}
