import { Component, input, OnChanges, output } from '@angular/core';
import { Student } from '../student.model';

@Component({
  selector: 'app-student-update',
  templateUrl: './student-update.component.html',
  styleUrls: ['./student-update.component.css'],
})
export class StudentUpdateComponent implements OnChanges {
  // @Input() student!: Student;
  // @Output() studentUpdated = new EventEmitter<Student>();
  // @Output() closeModal = new EventEmitter<void>();

  student = input<Student>();
  studentUpdated = output<Student>();
  closeModal = output<void>();

  updatedStudent!: Student;

  ngOnChanges(): void {
    if (this.student) {
      this.updatedStudent = { ...this.student() }; //Clone object without projects & hobbies
    }
  }

  saveChanges(): void {
    this.studentUpdated.emit(this.updatedStudent);
    this.closeModal.emit();
  }

  close(): void {
    this.closeModal.emit();
  }
}
