import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ConfirmPopUpComponent } from './confirm-pop-up/confirm-pop-up.component';
import { ResultUpdateComponent } from './result/result-update/result-update.component';
import { ResultComponent } from './result/result.component';
import { ResultPipe } from './result/result.pipe';
import { StudentAddComponent } from './student-add/student-add.component';
import { StudentDetailsComponent } from './student-details/student-details.component';
import { StudentListComponent } from './student-list/student-list.component';
import { StudentUpdateComponent } from './student-update/student-update.component';

@NgModule({
  declarations: [
    StudentListComponent,
    StudentDetailsComponent,
    StudentAddComponent,
    StudentUpdateComponent,
    ConfirmPopUpComponent,
    ResultComponent,
    ResultUpdateComponent,
    ResultPipe,
  ],
  imports: [CommonModule, FormsModule],
  exports: [
    StudentListComponent,
    StudentDetailsComponent,
    StudentAddComponent,
    StudentUpdateComponent,
    ConfirmPopUpComponent,
    ResultComponent,
    ResultUpdateComponent,
    ResultPipe,
  ],
})
export class StudentModule {}
