export interface Student {
  id: string;
  name: string;
  age: number;
  address: string;
  branch: string;
  cgpa: number;
  result: string;
  projects: string[];
  hobbies: string[];
}
