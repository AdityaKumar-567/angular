import { Component, computed, signal } from '@angular/core';
import { Student } from '../student.model';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css'],
})
export class ResultComponent {
  students = signal<Student[]>([]);
  selectedStudent = signal<Student | null>(null);
  isUpdateModalOpen = signal<boolean>(false);

  constructor(private studentService: StudentService) {
    this.loadStudents();
  }

  loadStudents() {
    this.students.set(this.studentService.getStudents());
  }

  selectStudent(student: Student) {
    this.selectedStudent.set(student);
    this.isUpdateModalOpen.set(true);
  }

  updateStudent(updatedStudent: Student) {
    this.studentService.updateStudent(updatedStudent);
    this.loadStudents();
    this.students.set([
      ...this.students().map((s) =>
        s.id === updatedStudent.id ? { ...s, result: updatedStudent.result } : s
      ),
    ]);
    this.isUpdateModalOpen.set(false);
  }

  closeModal() {
    this.isUpdateModalOpen.set(false);
  }

  //  Computed properties for Pass & Fail counts
  totalPass = computed(() => {
    return this.students().filter((s) => s.result === 'Pass').length;
  });

  totalFail = computed(() => {
    return this.students().filter((s) => s.result === 'Fail').length;
  });
}
