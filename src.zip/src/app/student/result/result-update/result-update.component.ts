import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
} from '@angular/core';
import { Student } from '../../student.model';

@Component({
  selector: 'app-result-update',
  templateUrl: './result-update.component.html',
  styleUrls: ['./result-update.component.css'],
})
export class ResultUpdateComponent implements OnChanges {
  @Input() student!: Student;
  @Output() studentUpdated = new EventEmitter<Student>();
  @Output() closeModal = new EventEmitter<void>();

  updatedStudent!: Student;

  ngOnChanges(): void {
    if (this.student) {
      this.updatedStudent = { ...this.student };
    }
  }

  saveChanges(): void {
    this.studentUpdated.emit(this.updatedStudent);
    this.closeModal.emit();
  }

  close(): void {
    this.closeModal.emit();
  }
}
