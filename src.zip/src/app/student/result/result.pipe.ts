import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'resultPipe',
})
export class ResultPipe implements PipeTransform {
  transform(value: string): string {
    return value === 'Pass'
      ? 'text-green-600 font-semibold'
      : 'text-red-500 font-semibold';
  }
}
