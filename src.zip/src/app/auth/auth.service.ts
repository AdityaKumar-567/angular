import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  // Signals for authentication state
  isLoggedInSignal = signal<boolean>(this.getLoginStatus());
  userRoleSignal = signal<string | null>(this.loadUserRole());

  private getLoginStatus(): boolean {
    return localStorage.getItem('isLoggedIn') === 'true';
  }

  private loadUserRole(): string | null {
    return localStorage.getItem('userRole');
  }

  isLoggedIn() {
    return this.isLoggedInSignal();
  }

  getUserRole() {
    return this.userRoleSignal();
  }

  signUp(firstName: string, lastName: string, username: string, password: string, Role: string): string {
    let users = JSON.parse(localStorage.getItem('users') || '[]');

    // Check if username already exists
    if (users.some((user: any) => user.username === username)) {
      return 'Username already exists!';
    }

    // Save user to local storage
    users.push({ firstName, lastName, username, password, role: Role });
    localStorage.setItem('users', JSON.stringify(users));

    return 'User registered successfully!';
  }

  login(username: string, password: string): string | null {
    let users = JSON.parse(localStorage.getItem('users') || '[]');
    let user = users.find((user: any) => user.username === username && user.password === password);

    if (user) {
      localStorage.setItem('isLoggedIn', 'true');
      localStorage.setItem('userRole', user.role);
      this.isLoggedInSignal.set(true);
      this.userRoleSignal.set(user.role);
      return user.role;
    } else {
      return null;
    }
  }

  logout(): void {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('userRole');
    this.isLoggedInSignal.set(false);
    this.userRoleSignal.set(null);
  }
}
