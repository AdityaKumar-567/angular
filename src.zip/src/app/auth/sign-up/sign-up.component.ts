import { Component } from '@angular/core';
import { AuthService } from '../auth.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrl: './sign-up.component.css'
})
export class SignUpComponent {
  firstName = '';
  lastName = '';
  username = '';
  Role = '';
  password = '';

  constructor(
    private authService: AuthService,
    private toastr: ToastrService,
    private router: Router
  ) {}

  signUp(): void {
    if (!this.firstName || !this.lastName || !this.username || !this.password || !this.Role) {
      this.toastr.error('All fields are required!', 'Validation Error');
      return;
    }

    let result = this.authService.signUp(this.firstName, this.lastName, this.username, this.password, this.Role);

    if (result === 'Username already exists!') {
      this.toastr.error(result, 'Sign Up Failed');
    } else {
      this.toastr.success(result, 'Sign Up Successful');
      this.router.navigate(['/login']); // Redirect to login page
    }
  }
}
