import { Component, EventEmitter, Input, Output, signal } from '@angular/core';
import { Student } from '../../student/student.model';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent {
  @Input() isLoggedIn = false; // Receive isLoggedIn from AppComponent
  @Input() userRole: string | null = null; //  Receive userRole from AppComponent
  @Output() logoutEvent = new EventEmitter<void>(); // Emit logout event

  showAddStudentModal = signal(false); // Uses Angular signal for modal visibility
  @Output() studentAdded = new EventEmitter<Student>(); // Event to send new student to parent

  logout(): void {
    this.logoutEvent.emit(); // Notify AppComponent to update isLoggedIn
  }

  onStudentAdded(student: Student): void {
    console.log('Student added here in header component ', student);
    this.studentAdded.emit(student); // Emit the student to update the list
    this.showAddStudentModal.set(false); // Close modal after adding student
  }
}
