import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routes';
import { AuthModule } from './auth/auth.module';
import { CoreModule } from './core/core.module';
import { StudentModule } from './student/student.module';
import { UserModule } from './user/user.module';

@NgModule({
  declarations: [AppComponent], // Only AppComponent should be declared here
  imports: [
    BrowserModule,
    CoreModule,
    AuthModule,
    StudentModule,
    AppRoutingModule, //  AppRoutingModule correctly imported here
    UserModule,
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
