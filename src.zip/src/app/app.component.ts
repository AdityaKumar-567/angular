import { Component, OnInit, computed } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './auth/auth.service';
import { Student } from './student/student.model';
import { StudentService } from './student/student.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  //Computed signals to track login state dynamically
  isLoggedInSignal = computed(() => this.authService.isLoggedIn());
  userRoleSignal = computed(() => this.authService.getUserRole());

  constructor(
    private authService: AuthService,
    private studentService: StudentService,
    private router: Router
  ) {}

  ngOnInit(): void {
    // No need to manually set signals, computed() will react to changes
  }

  handleLoginSuccess(): void {
    //  Computed signals will automatically update UI
    setTimeout(() => {
      const updatedRole = this.userRoleSignal();
      if (updatedRole === 'admin') {
        this.router.navigate(['/students']);
      } else if (updatedRole === 'user') {
        this.router.navigate(['/user']);
      }
    }, 100);
  }

  handleLogout(): void {
    this.authService.logout();
    this.router.navigate(['/']); //  Redirect to login after logout
  }

  handleAddStudent(student: Student): void {
    this.studentService.addStudent(student);
    console.log('Student added here app component', student);
  }
}
