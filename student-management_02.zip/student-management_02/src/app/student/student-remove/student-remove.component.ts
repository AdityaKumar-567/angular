import { Component, Output ,EventEmitter,signal } from '@angular/core';
import { Student } from '../student.model';
import { StudentService } from '../student.service';


@Component({
  selector: 'app-student-remove',
  templateUrl: './student-remove.component.html',
  styleUrl: './student-remove.component.css'
})
export class StudentRemoveComponent {

  searchQuery = '';

  students = signal<Student[]>([]);
  selectedStudent : Student | null = null;

  @Output() close = new EventEmitter<void>(); // Emit for closing modal
  


  constructor(private studentService: StudentService) {
    this.loadStudents();
  }

  loadStudents() {
    this.students.set(this.studentService.getStudents());
  }

  onSerchChange(query: string) {
    this.searchQuery = query;
    const filtered = this.studentService.getStudents().filter(student => 
      (student.name.toLowerCase().includes(query.toLowerCase())));

    this.students.set(filtered);
  }


  selectStudent(student: Student) {
    this.selectedStudent = student;
  }

  removeStudent() {
    if (this.selectedStudent) {
      this.studentService.removeStudent(this.selectedStudent.id);
      this.close.emit();
      console.log('Student removed here in remove component ', this.selectedStudent);
    }
  }

  closeModal() {
    // close the modal
    this.close.emit();
  }

}
