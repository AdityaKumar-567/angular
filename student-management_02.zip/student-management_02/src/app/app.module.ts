import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routes';
import { AuthModule } from './auth/auth.module'; 
import { CoreModule } from './core/core.module'; 
import { StudentModule } from './student/student.module'; 

@NgModule({
  declarations: [AppComponent], // Only AppComponent should be declared here
  imports: [
    BrowserModule,
    CoreModule,
    AuthModule,
    StudentModule,
    AppRoutingModule, // Routing should be in its own module
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
