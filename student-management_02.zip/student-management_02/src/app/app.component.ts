import { Component, Input } from '@angular/core';
import { Student } from './student/student.model';
import { StudentService } from './student/student.service';
import { AuthService } from './auth/auth.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  isLoggedIn:boolean = false;

  constructor(private authService:AuthService,  private studentService: StudentService) {
    this.isLoggedIn = this.authService.isLoggedIn();
  }

  handleLoginSuccess(): void {
    this.authService.login('admin','admin')
    this.isLoggedIn = true;
  }

  handleLogout(): void {
    this.authService.logout();
    this.isLoggedIn = false;
  }

  handleAddStudent(student: Student): void {
    this.studentService.addStudent(student);
    console.log('Student added here app componenet ', student);
    

  }



}
