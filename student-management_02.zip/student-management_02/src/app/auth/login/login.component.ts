import { Component, EventEmitter, inject, output, Output } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  username = '';
  password = '';
  errorMessage = '';

  // @Output() loginSuccess = new EventEmitter<void>();
  loginSuccess = output();
  // private authService :AuthService;
  // private toastr: ToastrService


  constructor(private authService:AuthService,  private toastr: ToastrService) {} // inject ToastrService

  // ngOnInit() : void{
  //   this.authService =inject(AuthService);
  //   this.toastr=  inject(ToastrService);
  // }

  

  login(): void {
    if (this.authService.login(this.username,this.password)){
        this.loginSuccess.emit();
    }
    else {
      this.toastr.error('invalid username or password', 'Login Failed');
    }
  }
}
