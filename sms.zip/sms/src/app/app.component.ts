import { Component } from '@angular/core';
// import { RouterLink, RouterOutlet } from '@angular/router';
// import { AddEmployeeComponent } from './components/add-employee/add-employee.component';
// import { EmployeeListComponent } from './components/employee-list/employee-list.component';
// import { DataBindingComponent } from './components/data-binding/data-binding.component';
// import { StructuralDirectiveComponent } from './components/directive/structural-directive/structural-directive.component';
// import { AttributeDirectiveComponent } from './components/directive/attribute-directive/attribute-directive.component';
// import { HeaderComponent } from "./components/udemy-course/header/header.component";
// import { UserComponent } from './components/udemy-course/user/user.component';

// import { DUMMY_USERS } from './dummy-users';
// import { TasksComponent } from "./components/udemy-course/tasks/tasks.component";
// import { NgFor, NgIf } from '@angular/common';
// import { GetApiComponent } from "./apiIntegration/get-api/get-api.component";
// import { PostApiComponent } from "./apiIntegration/post-api/post-api.component";
// import { EditApiComponent } from "./apiIntegration/edit-api/edit-api.component"
// import { DeleteApiComponent } from "./apiIntegration/delete-api/delete-api.component";
// import { NgContentComponent } from "./components/ng-template/ng-template.component";
// import { NgContainerComponent } from "./components/ng-container/ng-container.component";
// import { WebsiteContainerComponent } from "./website-container/website-container.component";

// @Component({
//   selector: 'app-root',
//   standalone: true,
//   imports: [WebsiteContainerComponent],
//   // imports: [AppComponent, RouterLink, RouterOutlet, GetApiComponent, PostApiComponent, EditApiComponent, DeleteApiComponent, NgContentComponent, NgContainerComponent, WebsiteContainerComponent],
//   // imports: [AppComponent, RouterOutlet, HeaderComponent, UserComponent, TasksComponent, NgFor, NgIf],
//   templateUrl: './app.component.html',
//   styleUrl: './app.component.css'
// })



// export class AppComponent {
  // selectedUser = DUMMY_USERS;
//   selectedUserId?: string ;

//   accpectDataFromChildComponent(id: string) {
//     this.selectedUserId = id;
//     console.log(" selected user id is " + id);
//   }

//   get selectedUserObject() {
//     return this.selectedUser.find( (user) => user.id === this.selectedUserId)!;
//   }

// }



@Component({
  selector: 'app-root',
  standalone: false,
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})


export class AppComponent {

}
