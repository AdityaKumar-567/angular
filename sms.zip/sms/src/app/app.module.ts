
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
// Custom created Moudle for Students
import { StudentModule } from './website-container/student/student.module';

import { AppComponent } from './app.component';
import { WebsiteContainerComponent } from './website-container/website-container.component';
import { HomePageComponent } from './website-container/home-page/home-page.component';
import { HeaderComponent } from './website-container/header/header.component';
// import { StudentHubComponent } from './website-container/student/student-hub/student-hub.component';
// import { StudentListComponent } from './website-container/student/student-list/student-list.component';
// import { StudentDetailsComponent } from './website-container/student/student-details/student-details.component';
import { LoginFormComponent } from './website-container/login-form/login-form.component';
import { NewStudentComponent } from "./website-container/student/new-student/new-student.component";
import { UpdateStudentComponent } from "./website-container/student/update-student/update-student.component";
import { CommonModule } from '@angular/common';


@NgModule({
    declarations: [ 
        LoginFormComponent,
        AppComponent, 
        WebsiteContainerComponent, 
        HomePageComponent, 
        HeaderComponent, 
    ],
    bootstrap: [ AppComponent ],
    imports: [BrowserModule, CommonModule, FormsModule, StudentModule, NewStudentComponent, UpdateStudentComponent]
})


export class AppModule {}