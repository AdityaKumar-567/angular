import { Component, EventEmitter, inject, Output } from '@angular/core';
import { LoginService } from './login.service';

@Component({
  selector: 'app-website-container',
  standalone: false,
  templateUrl: './website-container.component.html',
  styleUrl: './website-container.component.css'
})


export class WebsiteContainerComponent {

  public loginService = inject(LoginService);

}
