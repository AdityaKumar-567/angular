

export type Student = {
    id: string,
    name: string,
    semester: string,
    branch: string,
    grade: string,
    currentSemSubjects: string[],
    address: string,
    phone: string
}