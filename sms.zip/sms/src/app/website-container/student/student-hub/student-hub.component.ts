import { Component, computed, effect, inject, OnChanges, OnInit, signal } from '@angular/core';
import { Student } from '../student.model';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-hub',
  standalone: false,
  templateUrl: './student-hub.component.html',
  styleUrl: './student-hub.component.css'
})

// export class StudentHubComponent implements OnInit {

export class StudentHubComponent  {

  // Method - 1: To update UI on Student Add
  //studentList = computed(() => this.studentService.studentList());
  studentList = signal<Student[]>([]);
  public studentService = inject(StudentService);


  // Method - 2: To update UI on Student Add
  constructor() {
    effect(() => {
      this.studentList.set(this.studentService.getStudentList());
    })
  }


  // Method - 3: To update UI on Student Add( Not fully functional )
  // ngOnInit() {
  //   console.log('Use effect is loaded!');
  //   this.studentList.set(this.studentService.getStudentList());
  // }


  
  // get SelectedStudnet id Object From entrie Student List Using service
  get selectedStudentObject(): Student {
    return this.studentService.getSelectedStudent()!;
  }
}
