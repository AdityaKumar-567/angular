import { CommonModule } from '@angular/common';
import { Component, computed, EventEmitter, inject, Output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Student } from '../student.model';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-new-student',
  imports: [ FormsModule],
  templateUrl: './new-student.component.html',
  styleUrl: './new-student.component.css'
})


export class NewStudentComponent {

  public studentService = inject(StudentService);



  newStudent = signal({
    enteredName: '',
    enteredSemester: '',
    enteredBranch: '',
    enteredGrade: '',
    enteredCurrentSemSubjects: '',
    enteredAddress: '',
    enteredPhoneNo: '',
  })


  onAddNewStudent() {
    const newStudentObj: Student =  {
      id: (Date.now()).toString(),
      name: this.newStudent().enteredName,
      semester: this.newStudent().enteredSemester,
      branch: this.newStudent().enteredBranch,
      grade: this.newStudent().enteredGrade,
      currentSemSubjects: [],
      address: this.newStudent().enteredAddress,
      phone: this.newStudent().enteredPhoneNo
    }

    this.studentService.addStudent(newStudentObj);
    this.studentService.isAddingStudent.set(false);

  }


  onCancelNewStudent() {
    this.studentService.isAddingStudent.set(false);
  }


}
