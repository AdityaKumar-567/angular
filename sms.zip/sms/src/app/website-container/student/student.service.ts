
// Services contains the comman tasks performed by components

import { Injectable, signal } from "@angular/core";
import { studentList } from "./dummy-students";
import { Student } from "./student.model";
import { BehaviorSubject } from "rxjs";

@Injectable({
    providedIn: 'root',
}) 


export class StudentService {

    // Common code for student Hub
    studentList = signal<Student[]>(studentList); 
    selectedStudentId = signal<string>('');

    // get student dummy list
    getStudentList() {
        return this.studentList();
    }

    // get selected student object  --> than pass to Student Details Component
    getSelectedStudent() : Student{
        return this.studentList().find((student) => student.id == this.selectedStudentId() )!;
    }

    
    // Common code for student list
    displayStudentDetails(id: string) {
        this.selectedStudentId.set(id);
    }


    // common code for adding new-student component

    // signal for adding new student
    isAddingStudent = signal(false);





    addStudent( studentData: Student) {
        console.log("loaded");
        this.studentList.set([studentData, ...this.studentList()]);
    }

    removeStudent(studentId: string) {
        this.studentList.set(this.studentList().filter((student: { id: string; }) => student.id !== studentId ));
    }



    // update student details

    isUpdatingStudent = signal(false);

    updateStudent(updatedStudent: Student) {
        this.studentList.update((students) =>
            students.map(student =>
                student.id === updatedStudent.id ? { ...student, ...updatedStudent } : student
            )
        );
    }
}