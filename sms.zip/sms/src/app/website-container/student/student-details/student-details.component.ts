import { Component, inject, input, Input } from '@angular/core';
import { Student } from '../student.model';
import { StudentService } from '../student.service';
import { JsonPipe } from '@angular/common';

@Component({
  selector: 'app-student-details',
  standalone: false,
  templateUrl: './student-details.component.html',
  styleUrl: './student-details.component.css'
})


export class StudentDetailsComponent {

  
  // dependency injection of service
  private studentService = inject( StudentService);
  

  studentObj = input.required<Student>();


  
  // remove selected student
  removeStudent() {
    this.studentService.removeStudent(this.studentObj().id);
  }


  updateStudent() {
    this.studentService.isUpdatingStudent.set(true);
  }


}
