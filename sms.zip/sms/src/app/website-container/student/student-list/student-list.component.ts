import { Component, EventEmitter, inject, Input, Output } from '@angular/core';
import { type Student } from '../student.model';
import { StudentService } from '../student.service';


@Component({
  selector: 'app-student-list',
  standalone: false,
  templateUrl: './student-list.component.html',
  styleUrl: './student-list.component.css',
})


export class StudentListComponent {

  private studentService = inject( StudentService);
  @Input({required: true}) student!: Student;



  handleClick() {
    this.studentService.displayStudentDetails(this.student.id);
  }
  isSelected(): boolean {
    return this.studentService.selectedStudentId() === this.student.id;
  }
}
