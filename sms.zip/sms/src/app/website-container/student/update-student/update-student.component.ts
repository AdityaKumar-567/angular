import { Component, inject, signal } from '@angular/core';
import { StudentService } from '../student.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-update-student',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './update-student.component.html',
  styleUrl: './update-student.component.css'
})


export class UpdateStudentComponent {
  private studentService = inject(StudentService);



  updatedStudent = signal({
    enteredName: '',
    enteredSemester: '',
    enteredBranch: '',
    enteredGrade: '',
    enteredCurrentSemSubjects: '',
    enteredAddress: '',
    enteredPhoneNo: '',
  });

  student = this.studentService.getSelectedStudent();

  ngOnInit() {
    this.student = this.studentService.getSelectedStudent();
      this.updatedStudent.set({
        enteredName: this.student.name,
        enteredSemester: this.student.semester,
        enteredBranch: this.student.branch,
        enteredGrade: this.student.grade,
        enteredCurrentSemSubjects: this.student.currentSemSubjects.join(', '),
        enteredAddress: this.student.address,
        enteredPhoneNo: this.student.phone
    });
  }


  onUpdateStudent() {
    const updatedStudentObj = {
      id: this.student.id,
      name: this.updatedStudent().enteredName,
      semester: this.updatedStudent().enteredSemester,
      branch: this.updatedStudent().enteredBranch,
      grade: this.updatedStudent().enteredGrade,
      currentSemSubjects: this.updatedStudent().enteredCurrentSemSubjects.split(',').map(s => s.trim()),
      address: this.updatedStudent().enteredAddress,
      phone: this.updatedStudent().enteredPhoneNo
    }

    this.studentService.updateStudent(updatedStudentObj);
    this.studentService.isUpdatingStudent.set(false);            // close update dialog box
  }


  onCancelNewStudent() {
    this.studentService.isUpdatingStudent.set(false);
  }

}
