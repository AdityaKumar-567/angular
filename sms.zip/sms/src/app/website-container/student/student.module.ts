import { NgModule } from "@angular/core";

// StudentsModule Contains all Student Related Features to work Together.

import { StudentHubComponent } from "./student-hub/student-hub.component";
import { StudentListComponent } from "./student-list/student-list.component";
import { StudentDetailsComponent } from "./student-details/student-details.component";
import { CommonModule, JsonPipe } from "@angular/common";
import { UpdateStudentComponent } from "./update-student/update-student.component";


@NgModule({
    declarations: [
        StudentHubComponent,
        StudentListComponent,
        StudentDetailsComponent,
    ],
    exports: [StudentHubComponent],
    imports: [JsonPipe, CommonModule]
})


export class StudentModule {}