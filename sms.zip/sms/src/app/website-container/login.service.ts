import { EventEmitter, Injectable, Output, signal } from '@angular/core';

interface User {
  email: string;
  password: string;
}

interface LoginEvent {
  loginState: boolean;
  loginMessage: string;
}

@Injectable({
  providedIn: 'root'
})


export class LoginService {

  isAdminLogined = signal<boolean>(false);


  setAdminLoginTrue(val: boolean) {     // true
    this.isAdminLogined.set(val);
  }

  setAdminLogout(val: boolean) {      // false
    this.isAdminLogined.set(val);
  }



  handelOnSignIn(userObj: User, loginEventMessage: LoginEvent) {
    if (userObj.email == 'admin' && userObj.password == 'admin') {
      // set login --> true
      this.setAdminLoginTrue(true);
      // save credentails in local storage
      localStorage.setItem('loginUser', JSON.stringify(userObj));
      loginEventMessage.loginState = true;
    }
    else {
      loginEventMessage.loginMessage = 'Invalid Credentials';
    }
  }


}
