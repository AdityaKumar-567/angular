import { Component, EventEmitter, inject, Output } from '@angular/core';
import { LoginService } from '../login.service';
import { StudentService } from '../student/student.service';

@Component({
  selector: 'app-header',
  standalone: false,
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})


export class HeaderComponent {

  // login-logout service
  private loginService = inject(LoginService);

  onClickLogOutButton() {
    this.loginService.setAdminLogout(false);
  }




  // add new student service
  private studentService = inject(StudentService);
  
  addStudent() {
    this.studentService.isAddingStudent.set(true);
  }
  
}
