import { Component, EventEmitter, inject, Output, signal } from '@angular/core';
import { StudentService } from '../student/student.service';
import { Student } from '../student/student.model';

@Component({
  selector: 'app-home-page',
  standalone: false,
  templateUrl: './home-page.component.html',
  styleUrl: './home-page.component.css'
})

export class HomePageComponent {

  public studentService = inject(StudentService);


}
