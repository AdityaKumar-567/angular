import { Component, inject } from '@angular/core';
import { LoginService } from '../login.service';


interface User {
  email: string;
  password: string;
}

interface LoginEvent {
  loginState: boolean;
  loginMessage: string;
}

@Component({
  selector: 'app-login-form',
  standalone: false,
  templateUrl: './login-form.component.html',
  styleUrl: './login-form.component.css'
})


export class LoginFormComponent {

  private loginService = inject(LoginService);

  userObj: User = {
    email: '',
    password: ''
  }


  loginEventMessage: LoginEvent = {
    loginState: false,
    loginMessage: '',
  }


  onSign() {
    this.loginService.handelOnSignIn( this.userObj, this.loginEventMessage); 
  }

}

